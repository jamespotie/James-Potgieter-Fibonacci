from gettext import install
import argparse
import numpy as np

try:                                                                    #Ensures argument is present and is an integer
    parser = argparse.ArgumentParser()
    parser.add_argument("digs", type=int, help='Number of digits')
    args = parser.parse_args()
    digits = args.digs                                                  #Receives number of digits passed in as an argument
except:
    print("Invalid input.")
else:
    if (not type(digits) is int) or (digits<1):                         #Ensures number of digits is a counting number
        raise TypeError("Only counting numbers are allowed")
    t1 = 1
    t2 = 1
    count = 1                                                           
    temp = 1
    target = (np.power(np.uint64(10),np.uint64(np.subtract(digits,1))))
    
    while(np.floor_divide(t1, target) < 1):                             #Check whether term has exceeded target
        temp = t1 + t2
        t1 = t2
        t2 = temp
        count = np.add(count, 1)

    print(count)                                                        #Return term index to user
    
