from gettext import install

import argparse

import numpy as np

try:
    parser = argparse.ArgumentParser()
    parser.add_argument("digs", type=int, help='Number of digits')
    args = parser.parse_args()
    digits = args.digs
except:
    print("Invalid input.")
else:
    if (not type(digits) is int) or (digits<1):
        raise TypeError("Only counting numbers are allowed")
    t1 = 1
    t2 = 1
    count = 1
    temp = 1

    while((t1 / (np.power(10,digits-1))) < 1):
        temp = t1 + t2
        t1 = t2
        t2 = temp
        count = count + 1

    print(count)

